import React from "react";
import './aboutPage.css'
const AboutPage = () =>{
    return (
        <div className='aboutpage-container'>
            <h1>this is AboutPage</h1>
        </div>
    )
}
export default AboutPage;